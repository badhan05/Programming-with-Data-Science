# ID2214-Programming-for-Data-Science
ID2214 Programming for Data Science assignments

In this repository I uploaded the assignments done during the course of Programming for Data Science held at KTH.

Assignment 1: the aim is to write from srcatch pre-processing functions using pandas and numpy. Assignment 2: the aim is to build from scratch KNN and Naive Bayes classifiers. Assignment 3: the aim is to build a random forest classifier starting from the sklearn DecisionTreeClassifier. Chemical Compounds Classifier: this is the final project. The aim is to build and train a classifier for a multiclass dataset. Particularly the aim was to the checmical activity of a dataset of chemical compounds. After the problem was solved we wrote a report describing in detail our work.
